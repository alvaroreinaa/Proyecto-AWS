import json
import logging
import subprocess

import boto3
import uuid
from urllib.parse import unquote_plus

def lambda_handler(event, context):
     #xml_output = subprocess.check_output(["./exodus/bin/ffmpeg",
     #                                   "-y" ,"-hide_banner" ,
     #                                   "-loglevel", "panic",
     #                                   "-i", "https://pruebacalculadora.s3.eu-west-2.amazonaws.com/gl.mkv",
     #                                   "-ss", "00:00:00", 
     #                                   "-vframes" , "1",
     #
     #                              "/tmp/out.png"])
   
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = unquote_plus(record['s3']['object']['key'])
        temp = key.split("/")
        thumb_filename=key+"_thumb.gif"
        output_thumb="/tmp/" + temp[2] + "_thumb.gif"
        xml_output=subprocess.check_output(["./exodus/bin/ffmpeg",
                                        "-y" ,"-hide_banner" ,
                                        "-loglevel", "panic",
                                        "-i", "https://"+bucket+".s3.us-east-1.amazonaws.com/"+key,
                                        "-ss", "00:00:00", 
                                        "-t" , "3",
                                        "-filter_complex","[0:v] fps=4,scale=240:-1",
                                        output_thumb])
        s3 = boto3.resource("s3")
        s3.Bucket(bucket).upload_file(output_thumb,thumb_filename)
        object_acl = s3.ObjectAcl(bucket,thumb_filename)
        object_acl.put(ACL='public-read')
        
    return {
        'statusCode': 200,
        'headers': { 'Access-Control-Allow-Origin' : '*' },
        'body':json.dumps({ 'output' :  'ok' })
    }


